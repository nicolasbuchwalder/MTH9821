MTH 9821 - Homework 1

Group 6:
Li, Bingqian 
Wang, Mingsen
Li, Songjian
Buchwalder, Nicolas


Work repartition within group: 

Random Number Generators => Songjian
Part 1: Pricing path independent options  =>  Nicolas
Part 2: Pricing path dependent options  =>  Mingsen
Part 2: Comparing pricing of path independent options with different random generators  =>  Bingqian
